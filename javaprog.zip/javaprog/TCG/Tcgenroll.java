import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


class Test{
 static  int count;
 
    public static void main(String[] args) {
               
        JFrame frame=new JFrame("TCG Enrollment");
        frame.setSize(500,600);

        JLabel u_name=new JLabel("Name");
        u_name.setBounds(10, 10, 100, 50);
        
        JTextArea txt_name=new JTextArea();
        txt_name.setBounds(100, 10, 300, 50);
        txt_name.setBackground(Color.white);

        JLabel rank=new JLabel("Rank");
        rank.setBounds(10, 80, 100, 50);
        
        JTextArea txt_rank=new JTextArea();
        txt_rank.setBounds(100, 80, 300, 50);
        txt_rank.setBackground(Color.white);

        JLabel domain=new JLabel("Domain");
        domain.setBounds(10, 150, 100, 50);
        
        JTextArea txt_domain=new JTextArea();
        txt_domain.setBounds(100, 150, 300, 50);
        txt_domain.setBackground(Color.white);

        JLabel mobile=new JLabel("Mobile");
        mobile.setBounds(10, 220, 100, 50);
        
        JTextArea txt_mobile=new JTextArea();
        txt_mobile.setBounds(100, 220, 300, 50);
        txt_mobile.setBackground(Color.white);

        JLabel eid=new JLabel("Email ID");
        eid.setBounds(10, 290, 100, 50);
        
        JTextArea txt_eid=new JTextArea();
        txt_eid.setBounds(100, 290, 300, 50);
        txt_eid.setBackground(Color.white);

        JButton Enroll=new JButton("Enroll");
        Enroll.setBounds(100, 350, 80, 50);

        frame.add(u_name); frame.add(txt_name);
        frame.add(rank); frame.add(txt_rank);
        frame.add(domain); frame.add(txt_domain);
        frame.add(mobile); frame.add(txt_mobile);
        frame.add(eid); frame.add(txt_eid);
        frame.add(Enroll);
        frame.setLayout(null);
        frame.setVisible(true);
        ActionListener click=new ActionListener(){
            public void actionPerformed(ActionEvent e)
            { 
                String user_name,u_rank,u_domain,u_mob,mail_id;   
                user_name=txt_name.getText();
                u_rank=txt_rank.getText();
                u_domain=txt_domain.getText();
                u_mob=txt_mobile.getText();
                mail_id=txt_eid.getText();
                try {
                        File f=new File("Data7.json");
                        JSONParser parse=new JSONParser();
                        if(f.exists())
                        {  
                            
                            System.out.println("exit file");
                            Object obj=parse.parse(new FileReader("Data7.json"));                            
                            JSONArray arr=(JSONArray)obj;                           
                            int arrayLength= arr.size();
                           
                            JSONObject obj2=new JSONObject(); 
                            obj2=(JSONObject)arr.get(arrayLength-1);  
                            String Enroll_id=(String)obj2.get("Enroll");                        
                            
                            
                            JSONObject obj1=new JSONObject(); 
                            obj1.put("Enroll",String.valueOf(Integer.parseInt(Enroll_id)+1));
                            obj1.put("Name",user_name); 
                            obj1.put("Rank",u_rank); 
                            obj1.put("Domain",u_domain); 
                            obj1.put("Mob",u_mob); 
                            obj1.put("Mail",mail_id); 
                            arr.add(obj1);
                            FileWriter file=new FileWriter("Data7.json");
                                    file.write(arr.toString());
                                    file.close();
                                    System.out.println("JSON Data Updated");
                                    txt_name.setText("");
                                    txt_rank.setText("");
                                    txt_domain.setText("");
                                    txt_mobile.setText("");
                                    txt_eid.setText("");
                        }
                        else
                            {
                                f.createNewFile();
                                int enroll=0;
                                JSONObject id=new JSONObject(); 
                                JSONObject enid=new JSONObject();     
                                JSONArray arr=new JSONArray(); 
                                  
                                    id.put("Enroll",String.valueOf(enroll));
                                    id.put("Name",user_name); 
                                    id.put("Rank",u_rank); 
                                    id.put("Domain",u_domain); 
                                    id.put("Mob",u_mob); 
                                    id.put("Mail",mail_id); 
                                    
                                    arr.add(id);                             
                                    FileWriter file=new FileWriter("Data7.json");
                                    file.write(arr.toJSONString());
                                    file.close();
                                    System.out.println("JSON Data Updated");
                                    txt_name.setText("");
                                    txt_rank.setText("");
                                    txt_domain.setText("");
                                    txt_mobile.setText("");
                                    txt_eid.setText("");
                            }
                             
                } catch (Exception eee) {
                    System.out.println(eee);
                }
                
               
            }
        };
        Enroll.addActionListener(click);
    }
}