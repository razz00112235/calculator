import java.io.IOException;
import java.util.*;
class Trycatch{
   static void checkAge(int age) throws IOException
    {
        if(age<18)
        {
           throw new ArithmeticException();
        }
        else{
            System.out.println("Eligible for voating");
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your age");
        int age=sc.nextInt();
        try{
              checkAge(age);
 
        }catch(Exception e){
              System.out.println(e);
        }
            
    
    }
}