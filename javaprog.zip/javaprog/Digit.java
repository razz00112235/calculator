import java.util.*;
public class Digit{


    public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter Array Length");
      int ln=sc.nextInt();
      int num[]=new int[ln+1];     
      int temp,count=0;
      String output;
      for(int i=0;i<ln;i++)
      {
        num[i]=sc.nextInt();
      }
      System.out.println("Difference number");
      for(int j=0;j<ln;j++)
      {
        // System.out.println(num[j]);
        temp=num[j+1]-num[j]-1;
        count=temp;
        for(int k=0;k<count;k++)
        {
            System.out.print(++num[j]+",");
        }
        
        
      }
      
    }
    
}