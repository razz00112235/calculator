import java.util.*;
class Linkd{

    public static void main(String[] args) {
        LinkedList<Integer> que=new LinkedList<Integer>();
        
        que.add(0,10);
        que.add(1,20);
        que.add(2,30);
        que.add(3,40);
        que.add(4,50);
        System.out.println(que);
        
        System.out.println(que.size());
        Iterator e=que.descendingIterator();
        while(e.hasNext())  
           {  
               System.out.println(e.next()); 
              
           }  
           System.out.println(e.getFirst());
        
       
    }
}