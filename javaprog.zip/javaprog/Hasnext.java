import java.util.*;  
public class Hasnext {    
    public static void main(String args[]){       
         
        String name="Megh raj singh yadav";
        Scanner scan = new Scanner(name);
        while (scan.hasNext()) {  
            System.out.println(scan.next());  
        }  
        //Close the scanner  
        scan.close();  
        }    
}  