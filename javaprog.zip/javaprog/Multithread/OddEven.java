import java.util.*;

class Odd extends Thread{
  
     public void run()
     {
        for(int i=1;i<=20;i++)
        {
            if(i%2==0)
            {
                System.out.println(i);
                try {
                    sleep(500);
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
           
        }
     }

}
class Even extends Thread{
  
        public void run()
        {
            for(int i=1;i<=20;i++)
            {
                if(i%2!=0)
                {
                    System.out.println(i);
                    try {
                        sleep(500);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                }
            
            }
        }
   
}
class OddEven extends Thread{

    public static void main(String[] args) {
        
        OddEven oe=new OddEven();
        Odd od=new Odd();
        Even ev=new Even();
        od.start();
        ev.start();
    }
}