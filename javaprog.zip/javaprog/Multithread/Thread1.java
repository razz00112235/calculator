import java.util.*;
class Threaddata implements Runnable{
    public void run()
        {
            System.out.println("thread created 22...");
        }
    }
 class Thread1 extends Thread{

    public void run()
    {
        System.out.println("thread created...");
    }
    public static void main(String[] args) {
        Thread1 th=new Thread1();
        th.run();
        th.run();
        th.start();
        Threaddata td=new Threaddata();
        Thread t=new Thread(td);
        t.run();
        t.start();

    }
 }
