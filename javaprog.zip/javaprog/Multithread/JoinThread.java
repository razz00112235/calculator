import java.util.*;
class JoinThread1 extends Thread{

    public void run()
    {
        for(int i=0;i<5;i++)
        {
            System.out.println(i);
            try {
                sleep(500);
            } catch (Exception e) {
                // TODO: handle exception
            }
        
        }
    }
}
class JoinThread extends Thread{

    public void run()
    {
        for(int i=10;i<15;i++)
        {
            System.out.println(i);
            try {
                sleep(500);
            } catch (Exception e) {
                // TODO: handle exception
            }
        }
    }
    public static void main(String[] args) {
        JoinThread jt=new JoinThread();
        JoinThread jt2=new JoinThread();
        JoinThread1 jj=new JoinThread1();
        jt.run();
        try {
            sleep(500);
            //jt.join();
        } catch (Exception e) {
            // TODO: handle exception
        }
        jt2.run();
        jj.run();

    }
}