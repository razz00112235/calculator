import java.util.*;
class Threadcheck extends Thread{
    public void run()
    {
        System.out.println("With thread class");
        for(int i=10;i<15;i++)
        {
           
            try {
                System.out.println(i);
                sleep(600);
                System.out.println(currentThread());
            } catch (Exception e) {
                // TODO: handle exception
            }
            
        }
    }
}
 class SleepThread{
    public void data_thread()
    {
        System.out.println("Without extends thread class");
        for(int i=5;i<10;i++)
        {
           
            try {
                System.out.println(i);
                Thread.sleep(600);
                
            } catch (Exception e) {
                // TODO: handle exception
            }
            
        }
    }
    
    public static void main(String[] args) {
        SleepThread th=new SleepThread();
        th.data_thread();
        Threadcheck tc=new Threadcheck();
        tc.run();
       

    }
 }
