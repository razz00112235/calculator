import java.util.*;
class Thread_one extends Thread{
    
   public void run()
   {
    Scanner sc2=new Scanner(System.in);
    for(int i=0;i<5;i++)
    {
        System.out.println("Enter id");
        int id=sc2.nextInt();
    }
   
   }

}
class Thread_two implements Runnable{
    
    public void run()
    {
        
        Scanner sc1=new Scanner(System.in);
        for(int j=10;j<15;j++)
        {
            System.out.println("Enter name");
            String Name=sc1.nextLine();
        }
        
    }
 
 }

class Thred1{
    public static void main(String[] args) {
        Thred1 t1=new Thred1();
        Thread_one t2=new Thread_one();
        Thread_two t3=new Thread_two();
        Thread t=new Thread(t3);
        t2.start();
        try {
            t2.join();
        } catch (Exception e) {
            // TODO: handle exception
        }
        t.start();
        


    }
}