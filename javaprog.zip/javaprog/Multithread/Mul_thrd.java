import java.lang.*;
import java.io.IOException;
class Demo1 extends Thread{

    public void run(){
        for(int i=0;i<5;i++)
        {
            if(i==3){ throw new ArithmeticException();}
            System.out.println(i);
            try{
                Thread.sleep(500);
            }
            catch(Exception e)
            {
                System.out.println(e);
            }
        }
    }
    
}
class Demo2 extends Thread{
   public void run()
    {
        for(int i=10;i<15;i++)
        {
            System.out.println(i);
            try{
                Thread.sleep(500);
            }
            catch(Exception e)
            {
                System.out.println(e);
            }
        }
    }
}
public class Mul_thrd 
{
    
    public static void main(String[] args) {
        ArithmeticException obj = new ArithmeticException();  
        Demo1 d=new Demo1();
        d.start();
        Demo2 d2=new Demo2();
        d2.start();
    }
}