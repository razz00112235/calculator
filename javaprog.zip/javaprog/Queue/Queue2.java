import java.util.*;
class Queue2{

    public static void main(String[] args) {
        Queue<Integer> que=new LinkedList<Integer>();
        try {
            for(int i=0;i<10;i++)
            {
                que.add(i);
                System.out.println(que);
                Thread.sleep(1000);
                if(que.size()==5)
                {
                     que.remove();
                }
                
            }
        } catch (Exception e) {
            // TODO: handle exception
        }
    }
}