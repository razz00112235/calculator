import java.util.*;






class Quue{
int temp[]=new int[10];
int r=-1,f=-1;
    void enque(int num)
    {
      System.out.println(num);
      if(f==0 && r==10)
      {
        System.out.println("Queue is full");
      }
       else if((r==-1)&&(f==-1))
       {
        f=0;r=0;temp[r]=num;
        System.out.println("data entered 1 st time");        
       }
       else
       {
        temp[r]=num;
        System.out.println("data entered after 1 st time");        
       }
       r++;       
    }

    int deque()
    {
        f=f+1;      
        return f;
    }

        public static void main(String[] args) {
            Quue obj=new Quue();
            obj.enque(2);
            obj.enque(5);
            obj.enque(8);
            obj.enque(10);
            obj.enque(55);
            obj.enque(62);
            obj.enque(110);
            obj.enque(10);
            obj.enque(55);
            obj.enque(62);
            obj.enque(110);
        System.out.println("After Inqueue.........");
        int temp2[]=new int[10];
        temp2=obj.temp;        
        for(int i=0;i<obj.r-1;i++)
        {
            System.out.println(temp2[i]);
        }
        System.out.println("After Dequeue.........");
        int temp3[]=new int[10];
        temp3=obj.temp;
        int x=obj.deque();
        x=obj.deque();
        x=obj.deque();
        
        for(int i=x;i<obj.r-1;i++)
        {
            System.out.println(temp3[i]);
         }
     }    
}