import java.util.*;
import java.net.*;
import java.io.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
 class Apidata{

    public static void main(String[] args) {

        try {
              JSONParser par3=new JSONParser();
              Object objdata = par3.parse(new FileReader("api.json"));
              JSONObject obj2=(JSONObject)objdata;            
              JSONObject obj3=(JSONObject)obj2.get("channel");     
              Object name,id;
              name=obj3.get("name");
              id=obj3.get("id");
              System.out.println("name: "+name);
              System.out.println("id:"+id);
              JSONArray wth = (JSONArray)obj2.get("feeds");
              Object value;
              System.out.println("Value of Field1 are:--");
              for(int i=0;i<wth.size();i++)
              {
                JSONObject obj4=(JSONObject)wth.get(i);
                value=obj4.get("field1");
                System.out.println("Field1:"+value);
              }
        } catch (Exception e) {
            // TODO: handle exception
        }
        
    }
 }