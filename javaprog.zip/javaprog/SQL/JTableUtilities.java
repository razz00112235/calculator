import javax.swing.JTable;

public class JTableUtilities {

    public static void setCellsAlignment(JTable table, int center) {
    }

}
