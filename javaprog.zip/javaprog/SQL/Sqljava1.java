import java.sql.*;

public class Sqljava1{

    public static void main(String[] args) {
       
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", 
            "root", "12345");
           
            String qry="Select * from persons";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(qry);

            // String qry="UPDATE persons SET City = 'Jaipur' WHERE PersonID = 3";
            // Statement st=con.createStatement();
            // st.executeUpdate(qry);
           
           while(rs.next())
           {
             int id=rs.getInt("PersonID");
            //  int c_id=rs.getInt("help_keyword_id");
             System.out.println(id);

           }

        } catch (Exception e) {
            System.out.println(e);
        }
       
    }
}