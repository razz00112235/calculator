import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
class Radio {
  
    
    public static void main(String[] args)
    {
       
    }
  
   
}