import javax.swing.*;    
import java.awt.event.*;    
import java.io.FileReader;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
class OnlineTest{
    static JRadioButton op1,op2,op3,op4;
    static JLabel ans,u_ans,question;
    static JButton next;
    static String qt,obj1,obj2,obj3,obj4,ans_qst;
    static int qst_count=0;
    public void test()
    {        
        
        
    }
    

        
    public static void main(String[] args) {
        OnlineTest ts=new OnlineTest();
        JFrame frame=new JFrame("Online Test");
        frame.setBounds(150, 150, 400, 500);  
        System.out.println(qst_count);     
        JSONParser parser=new JSONParser();  
        try {
                 Object obj=parser.parse(new FileReader("test.json")); 
                 JSONArray arr=(JSONArray)obj;  
                                    
                JSONObject objdata=(JSONObject)arr.get(qst_count);                     
                qt=(String)objdata.get("Question");
                obj1=(String)objdata.get("A");
                obj2=(String)objdata.get("B");
                obj3=(String)objdata.get("C");
                obj4=(String)objdata.get("D");
                ans_qst=(String)objdata.get("ANS"); 
                

        } catch (Exception e) {
            System.out.println(e);
        }
        question=new JLabel(qt);
        question.setBounds(10, 5, 150, 50);
        op1=new JRadioButton(obj1);
        op1.setBounds(10, 50, 150, 50);
        op2=new JRadioButton(obj2);
        op2.setBounds(10, 100, 150, 50);
        op3=new JRadioButton(obj3);
        op3.setBounds(10, 150, 150, 50);
        op4=new JRadioButton(obj4);
        op4.setBounds(10, 200, 150, 50);
        ButtonGroup bg=new ButtonGroup(); 
        bg.add(op1);bg.add(op2);bg.add(op3);bg.add(op4);

        next=new JButton("Next");
        next.setBounds(150,300,150,50);
        ans=new JLabel(ans_qst);
        ans.setBounds(10, 250, 150, 50);
        u_ans=new JLabel("user_ans:-");
        u_ans.setBounds(250, 250, 250, 50);

        frame.add(op1);frame.add(op2);frame.add(op3);frame.add(op4);frame.add(ans);
        frame.add(u_ans);frame.add(question);frame.add(next);
        frame.setLayout(null);
        frame.setVisible(true);
        ActionListener click=new ActionListener(){
            public void actionPerformed(ActionEvent ee)
            { 
                qst_count++;
            }
        };
        next.addActionListener(click);
        ActionListener opcheck=new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {
                if(op1.isSelected()){    
                    u_ans.setText(op1.getText());
                  } 
                  else if(op2.isSelected()){    
                           u_ans.setText(op2.getText());
                    } 
                 else if(op3.isSelected()){    
                            u_ans.setText(op3.getText());
                   } 
                   else if(op4.isSelected()){    
                    u_ans.setText(op4.getText());
                  } 
            }
        };
        op1.addActionListener(opcheck);
        op2.addActionListener(opcheck);
        op3.addActionListener(opcheck);
        op4.addActionListener(opcheck);
    }

}