import javax.sound.midi.Soundbank;
import java.util.*;
class Dsa{
    int top=-1,capacity=10;
    int a[]=new int[10];
    void push(int x)
    {
        

       if(top==capacity-1)
       {
        System.out.println("Stack Overflow");
       }
       else
       {
        top=top+1;      
        a[top]=x;
       // System.out.println("data entered");
       }
       
    }
    int pop()
    {
     
      if(top==-1)
      {
        System.out.println("Stack Empty");
      }
      else
      {        
        System.out.println(a[top]+"Data pop");
        top=top-1;
      }
       
        
        return a[top];
    }
}

class Stck{

    public static void main(String[] args) {
        Dsa obj=new Dsa();
        obj.push(25);
        obj.push(30);
        obj.push(35);
        obj.push(5);
        obj.push(16);
        obj.push(99);
        obj.push(365);
        obj.push(82);
        System.out.println("Data Before POP");
        int b[]=new int[10];
        b=obj.a;
        for(int i=0;i<b.length;i++)
        {
         System.out.println(b[i]);
        }
        System.out.println("\nAfter POP Operation-------");
        obj.pop();       
        obj.pop();
        obj.pop();
        System.out.println("\n");
        System.out.println("Data After pop");
        int c[]=new int[10];
        c=obj.a;
        for(int i=0;i<obj.top+1;i++)
        {
         System.out.println(c[i]);
        }























         /*Scanner sc=new Scanner(System.in);
        System.out.println("Enter marks");
        for(int i=0;i<=10;i++)
        {
            int num=sc.nextInt();
            obj.push(num);
        }
        int b[]=new int[10];
        b=obj.a;
        for(int i=0;i<b.length;i++)
        {
         System.out.println(b[i]);
        }*/
    }
}