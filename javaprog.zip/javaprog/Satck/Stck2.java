import java.util.*;
import java.util.Stack;  
class Stck2
{
  
     public static void main(String[] args) {
        Stack<String> sc=new Stack<>();
        Stack<Integer> in=new Stack<>();
        sc.push("ram");
        sc.push("karan");
        sc.push("shyam");
        in.push(5);
        in.push(13);
        in.push(52);
        in.push(56);
        in.push(58);
        in.push(115);
        System.out.println(sc);
        System.out.println(in);
        System.out.println("After pop...........");
        in.pop();in.pop();
        sc.pop();
        System.out.println(sc);
        System.out.println(in);
        System.out.println("Other methods in Stack...........");
       System.out.println("Capacity in Stack: "+sc.capacity());
       System.out.println("Peek in Stack: "+sc.peek());
       System.out.println("Peek in Stack: "+in.peek());
     }
}
