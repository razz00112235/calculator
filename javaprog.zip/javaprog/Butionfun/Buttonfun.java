import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class Buttonfun{
       
    public static void main(String[] args) {
        JFrame fr=new JFrame("Button Action");
        fr.setSize(500, 500);
        JButton b1=new JButton("3");
        b1.setBounds(50, 50, 100, 50);
        fr.setLayout(null);
        fr.add(b1);

        JFrame fr2=new JFrame("Frame Demo");       
        // fr2.setSize(200, 200);      
        fr2.setBounds(200, 100, 200, 200);
        JButton b2=new JButton("5");
        b2.setBounds(50, 50, 100, 50);
        fr2.setLayout(null);
        fr2.add(b2);

        ActionListener click=new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {
                fr.setVisible(false);
                fr2.setVisible(true);
            }
        };

        ActionListener hide=new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {              
                fr2.setVisible(false);
                fr.setVisible(true);
            }

        };
        b1.addActionListener(click);    
        b2.addActionListener(hide);    
        fr.setVisible(true);
    }
}