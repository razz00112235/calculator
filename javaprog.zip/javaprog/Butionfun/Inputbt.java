import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Inputbt{

    public static void main(String[] args) {
        
        JFrame frame=new JFrame("Panel Calculator");
        frame.setSize(500,500);
        JTextArea txt=new JTextArea();
        txt.setBounds(10, 10, 460, 100);
        txt.setBackground(Color.pink);
        
       JButton b1=new JButton("click");
       b1.setBounds(100,100,100,50);
       
        
        frame.add(txt); 
        frame.add(b1);
        frame.setLayout(null);
        frame.setVisible(true);

        ActionListener click=new ActionListener(){
            int count=0;
            public void actionPerformed(ActionEvent e)           
            {
                count++;
                txt.setText("count"+count);
                b1.setText("count"+count);
            }
        };
        b1.addActionListener(click);
    }
}