import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.String.*;
import java.security.spec.X509EncodedKeySpec;
public class Democal{
  static  String temp_str="",opr;  
  static int i=0,num=0,count=0,finaldata,tmp1,tmp2,sum=0,num1,num2,num3,num4;
  static String data_in[]=new String[20]; 
    public static void main(String[] args) {
        
        JFrame frame=new JFrame("Panel Calculator");
        frame.setSize(500,600);
        JTextArea txt=new JTextArea();
        txt.setBounds(10, 10, 460, 100);
        txt.setBackground(Color.pink);
        JLabel show=new JLabel("output");
        show.setBounds(100, 500, 300, 100);
        JPanel panel=new JPanel();
        panel.setBounds(0,120,500,320);    
        panel.setBackground(Color.gray);  
        GridLayout layout = new GridLayout(4,4);       
        panel.setLayout(layout);
       String bt[]={"1","2","3","+","4","5","6","-","7","8","9","*","/",".","0","="};
     
       for(i=0;i<bt.length;i++)
       {
        JButton btn;
         btn=new JButton();  
         btn.setText(""+bt[i]);
         panel.add(btn);   
            ActionListener click=new ActionListener(){
              public void actionPerformed(ActionEvent e)
              {  
                               
                char in_num[]=new char[20];          
                String data,y="",indata,outstring;                
                data=btn.getText(); 
                indata=txt.getText();             
                show.setText(data);
                outstring=indata+data;
                txt.setText(outstring);
                if(!data.equals("+") && !data.equals("*") && !data.equals("-")
                && !data.equals("/") && !data.equals("="))
                {
                  temp_str=temp_str+data;                 
                  show.setText(temp_str);
  
                }                
                else
                {      
                      data_in[count]=temp_str;  
                      count++;  
                      data_in[count]=data; 
                      count++;                                           
                      temp_str="";
                  if(data.equals("="))
                  {                    
                     for(int k=0;k<count;k++)
                     {                                            
                      if(data_in[k].equals("+")||data_in[k].equals("=")||data_in[k].equals("-")||data_in[k].equals("*")
                      ||data_in[k].equals("/"))
                      {
                        opr=data_in[k];                        
                        if(!opr.equals("="))
                        {
                            tmp2=Integer.parseInt(data_in[k+1]);
                            if(data_in[k].equals("+"))
                            {
                              sum=sum+tmp2;                               
                            }
                            else if(data_in[k].equals("-"))
                            {
                                sum=sum-tmp2;
                            }
                            else if(data_in[k].equals("*"))
                            {
                                sum=sum*tmp2;
                            }
                            else if(data_in[k].equals("/"))
                            {
                                sum=sum/tmp2;
                            }                         
                            
                        }
                        else
                        {
                          txt.setText(outstring+sum);
                          show.setText(String.valueOf(sum));
                        }                       
                        k=k+1;                       
                      }
                      else
                      {
                        if(data_in[k+1].equals("="))
                        {
                          txt.setText(outstring+sum);                                                   
                        }
                        else
                        {
                          tmp1=Integer.parseInt(data_in[k]);tmp2=Integer.parseInt(data_in[k+2]);
                          opr=data_in[k+1];
                           if(opr.equals("+"))
                            {
                              sum=tmp1+tmp2;
                            }
                            else if(opr.equals("-"))
                            {
                              sum=tmp1-tmp2;
                            }
                            else if(opr.equals("*"))
                            {
                              sum=tmp1*tmp2;
                            }
                            else if(opr.equals("/"))
                            {
                              sum=tmp1/tmp2;
                            }         
                           k=k+2;
                        }
                        
                      }
                                             
                     }
                     
                  }
                             
                  
                }          
                
              }

          };
          btn.addActionListener(click);       
              
       }      
        frame.add(txt); 
        frame.add(panel);
        frame.add(show);
        frame.setLayout(null);
        frame.setVisible(true);       

   
      
      
      

    }
}