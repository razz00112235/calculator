import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Userinterface{

    public static void main(String[] args) {
        DefaultListModel<String> lst1=new DefaultListModel<String>();
        lst1.addElement("A");lst1.addElement("B");
        lst1.addElement("C");lst1.addElement("D");
        //List<
    }
}