import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Loginpage{

    public static void main(String[] args) {
        JFrame frame=new JFrame("Login Page");
        frame.setSize(500,600);  
        JLabel lb=new JLabel("mail");
        lb.setBounds(50, 0, 50, 30);        

        JTextField  mail=new JTextField(10);         
        mail.setBounds(100, 10, 200, 30);       

        JLabel lb2=new JLabel("pass");
        lb2.setBounds(50, 100, 50, 30);           
        
        JTextField  pass=new JTextField(10);         
        pass.setBounds(100, 100, 200, 30);        
        
        JButton bt1=new JButton("Login");
        bt1.setBounds(100, 200, 150, 50);     
        
        JLabel output=new JLabel();
        output.setBounds(100, 280, 300, 50);

        JLabel result=new JLabel();
        result.setBounds(100, 300, 300, 50);

        frame.add(lb);
        frame.add(mail);
        frame.add(lb2);
        frame.add(pass);
        frame.add(bt1);
        frame.add(output);
        frame.add(result);
        frame.setLayout(null);  
        frame.setVisible(true);

        ActionListener click=new ActionListener(){         
            public void actionPerformed(ActionEvent e)           
            { 
                output.setText("Mail:-"+mail.getText()+" Pass:-"+pass.getText());
                result.setText("Login success..");
            }
        };
        bt1.addActionListener(click);
    }
}