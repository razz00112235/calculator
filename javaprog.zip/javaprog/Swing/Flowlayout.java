import javax.sound.midi.Soundbank;
import javax.swing.*;
import java.awt.*;

class Flowlayout{

    public static void main(String[] args) {
        JFrame frame=new JFrame("Flow Layout");
        frame.setSize(500,500);
        JButton b1=new JButton("1");       
        JButton b2=new JButton("2");
        JButton b3=new JButton("3");
        JButton b4=new JButton("4");
        frame.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 25));       
        frame.add(b1);
        frame.add(b2);
        frame.add(b3);
        frame.add(b4);

        String s1[] = { "Jalpaiguri", "Mumbai", "Noida", "Kolkata", "New Delhi" };
        JComboBox c1 = new JComboBox(s1);
        frame.add(c1);

        JCheckBox check1,check2,check3;
        check1=new JCheckBox("Java");check2=new JCheckBox("C++");
        check3=new JCheckBox("PHP");
        frame.add(check1);
        frame.add(check2);
        frame.add(check3);

        JRadioButton male,female;
        male=new JRadioButton("male",true);
        female=new JRadioButton("female");

        frame.add(male);frame.add(female);
        frame.setVisible(true);

    }
}