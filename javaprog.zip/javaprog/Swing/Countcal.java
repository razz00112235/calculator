import java.util.*;
import java.util.String.*;
public class Countcal{
 static int add=0;
 static int ln_count;
    public static void main(String[] args) {
        
        String data[]={"25","+","30","="};
        String div_data[]=new String[30];
        String mul_data[]=new String[30];
        String add_data[]=new String[30];
        String sub_data[]=new String[30];
        int mul,sub;
        for(int i=0;i<data.length;i++)
        {
           
            if(data[i].equals("/"))
            {    
                if(data[i-1].equals("")) 
                {
                    mul=Integer.parseInt(data[0])/Integer.parseInt(data[i+1]);
                    data[0]=String.valueOf(mul);
                    data[i]="";data[i+1]="";
                } 
                else
                {
                    mul=Integer.parseInt(data[i-1])/Integer.parseInt(data[i+1]);
                    data[i-1]=String.valueOf(mul);
                    data[i]="";data[i+1]="";
                }          
                
            }
            
            for(int j=0,k=0;j<data.length;j++)
            {
                if(!data[j].equals(""))
                {
                    div_data[k]=data[j];
                    k++;
                }

            }            
        }
        int count4=0;
        for(String a:div_data)
        {      
            //System.out.println(a);       
             if(a.equals("="))
            {
                ln_count=count4;
                break;
            }
            count4++;             
                          
        }

        for(int i=0;i<ln_count+1;i++)
        {
          
            if(div_data[i].equals("*"))
            {    
                if(div_data[i-1].equals("")) 
                {
                    mul=Integer.parseInt(div_data[i-3])*Integer.parseInt(div_data[i+1]);
                    div_data[i-3]=String.valueOf(mul);
                    div_data[i]="";div_data[i+1]="";
                } 
                else
                {
                   
                    mul=Integer.parseInt(div_data[i-1])*Integer.parseInt(div_data[i+1]);
                    div_data[i-1]=String.valueOf(mul);
                    div_data[i]="";div_data[i+1]="";
                }          
                
            }
            
            for(int j=0,k=0;j<ln_count+1;j++)
            {
                if(!div_data[j].equals(""))
                {
                    mul_data[k]=div_data[j];
                    k++;
                }

            }            
        }
        int count=0;
        for(String a:mul_data)
        {      
           // System.out.println(a);       
             if(a.equals("="))
            {
                ln_count=count;
                break;
            }
            count++;             
                          
        }
    
        for(int m=0;m<ln_count+1;m++)
        {           
            if(mul_data[m].equals("+"))
            {
                
                if(mul_data[m-1].equals(""))
                {
                    add=Integer.parseInt(mul_data[0])+Integer.parseInt(mul_data[m+1]);
                    mul_data[0]=String.valueOf(add);
                    mul_data[m]="";mul_data[m+1]="";
                }
                else if(!mul_data[m-1].equals("")&& !mul_data[m+1].equals(""))
                {
                    
                    if(mul_data[m-1].equals(""))
                    {
                        add=Integer.parseInt(mul_data[m-3])+Integer.parseInt(mul_data[m+1]);                           
                        mul_data[m-3]=String.valueOf(add);
                        mul_data[m]="";mul_data[m+1]="";
                    }
                    else
                    {
                        add=Integer.parseInt(mul_data[m-1])+Integer.parseInt(mul_data[m+1]);                           
                        mul_data[m-1]=String.valueOf(add);
                        mul_data[m]="";mul_data[m+1]="";
                    }
                    
                }
               
            }
        
            for(int j=0,k=0;j<ln_count+1;j++)
            {
                if(!mul_data[j].equals(""))
                {
                    add_data[k]=mul_data[j];
                    k++;
                }

            }
        }
        int count2=0;
        for(String b:add_data)
        {
            //System.out.println(b);
            if(b.equals("="))
            {
                ln_count=count2;
                break;
            }
            count2++;
            
        }
       for(int i=0;i<ln_count+1;i++)
       {
          if(add_data[i].equals("-"))
          {
                 if(add_data[i-1].equals(""))
                 {
                    sub=Integer.parseInt(add_data[i-3])-Integer.parseInt(add_data[i+1]);                           
                    add_data[i-3]=String.valueOf(sub);
                    add_data[i]="";add_data[i+1]="";
                 }
                 else
                 {
                    sub=Integer.parseInt(add_data[i-1])-Integer.parseInt(add_data[i+1]);                           
                    add_data[i-1]=String.valueOf(sub);
                    add_data[i]="";add_data[i+1]="";
                 }
                    
          }
          for(int j=0,k=0;j<ln_count+1;j++)
            {
                if(!add_data[j].equals(""))
                {
                    sub_data[k]=add_data[j];
                    k++;
                }

            }
       }
        int count3=0;
        for(String c:sub_data)
        {
            //System.out.println(c);           
            
        }
        if(sub_data[1].equals("="))
        {
            System.out.println("Final value:"+sub_data[0]);
        }
    }
}