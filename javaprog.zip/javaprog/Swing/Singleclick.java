import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Singleclick{
    static JFrame frame=new JFrame();
    
    
    
    public static void main(String[] args) {
        
        frame.setSize(400,400);
        frame.setLayout(null);

        JButton on=new JButton("OFF");
        on.setBounds(10,10,100,50);      
        JLabel pik=new JLabel();
        pik.setBounds(100, 150, 200, 200);
        pik.setIcon(new ImageIcon("pic_bulboff.gif"));
        ActionListener on_click=new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {    
                String check;
                check=on.getText();                
                if(check.equals("ON"))
                {
                    pik.setIcon(new ImageIcon("pic_bulboff.gif"));
                    on.setText("OFF");
                }
                else if(check.equals("OFF"))      
                {
                    pik.setIcon(new ImageIcon("pic_bulbon.gif"));
                    on.setText("ON");
                }
                
            }

        };
        on.addActionListener(on_click);
        frame.add(on);frame.add(pik);
        frame.setVisible(true);
    }
}