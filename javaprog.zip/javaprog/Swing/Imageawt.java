import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Imageawt{
    static JFrame frame=new JFrame();
    static JButton on=new JButton("ON");
    static JButton off=new JButton("OFF");
    
    public static void main(String[] args) {
        
        frame.setSize(400,400);
        frame.setLayout(null);

        on.setBounds(10,10,100,50);
        off.setBounds(10,100,100,50);
        
        JLabel pik=new JLabel();
        pik.setBounds(100, 150, 200, 200);
        pik.setIcon(new ImageIcon("pic_bulboff.gif"));
        ActionListener on_click=new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {               
                pik.setIcon(new ImageIcon("pic_bulbon.gif"));
            }

        };
        on.addActionListener(on_click);   
        
        ActionListener off_click=new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {               
                pik.setIcon(new ImageIcon("pic_bulboff.gif"));
            }

        };
        off.addActionListener(off_click); 
        frame.add(on);frame.add(off);frame.add(pik);

        frame.setVisible(true);
    }
}