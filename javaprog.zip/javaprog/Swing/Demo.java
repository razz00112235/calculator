import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.String.*;
import java.security.cert.X509CRLSelector;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import java.lang.NullPointerException;
public class Demo{
  static  String temp_str="",opr,outstring;  
  static int i=0,num=0,count=0,finaldata,tmp1,tmp2,sum=0;
  static String data_in[]=new String[20]; 
  static int add=0;
  static int ln_count;
  static int mul,sub,rest_data=0;
  
    public static void main(String[] args) {
        String div_data[]=new String[30];
        String mul_data[]=new String[30];
        String add_data[]=new String[30];
        String sub_data[]=new String[30];
       
        
        JFrame frame=new JFrame("Panel Calculator");
        frame.setSize(500,600);
        JTextArea txt=new JTextArea();
        txt.setBounds(10, 10, 460, 100);
        txt.setBackground(Color.pink);        
        JPanel panel=new JPanel();
        panel.setBounds(0,120,500,320);    
        panel.setBackground(Color.gray);  
        GridLayout layout = new GridLayout(4,4);       
        panel.setLayout(layout);
       String bt[]={"1","2","3","+","4","5","6","-","7","8","9","*","/",".","0","="};
       JButton rest=new JButton("AC");
       rest.setBounds(100, 450, 100, 50);
       for(i=0;i<bt.length;i++)
       {
        JButton btn;
         btn=new JButton();  
         btn.setText(""+bt[i]);
         panel.add(btn);   
            ActionListener click=new ActionListener(){
              public void actionPerformed(ActionEvent e)
              {  
                               
                char in_num[]=new char[20];          
                String data,y="",indata;                
                data=btn.getText(); 
                indata=txt.getText(); 
                outstring=indata+data;
                txt.setText(outstring);
                //System.out.println(outstring);
                if(!data.equals("+") && !data.equals("*") && !data.equals("-")
                && !data.equals("/") && !data.equals("="))
                {
                        temp_str=temp_str+data;  
                              
                }                
                else
                {  
                   
                        data_in[count]=temp_str;  
                        count++;  
                        data_in[count]=data; 
                        count++;                                           
                        temp_str="";
                  
                  if(data.equals("="))
                  {     
                    int count_arr=0;
                                for(int aj=0;aj<data_in.length;aj++)
                                {
                                    if(data_in[aj]!=null)
                                    {
                                        count_arr++;                                        
                                    }                                 
                                    
                                }
                              
                    for(int ai=0;ai<count_arr;ai++)
                            {
                                //System.out.println(data_in[ai]);
                               
                                        if(data_in[ai].equals("/"))
                                        {    
                                            if(data_in[ai-1].equals("")) 
                                            {
                                                mul=Integer.parseInt(data_in[0])/Integer.parseInt(data_in[ai+1]);
                                                data_in[0]=String.valueOf(mul);
                                                data_in[ai]="";data_in[ai+1]="";
                                            } 
                                            else
                                            {
                                                mul=Integer.parseInt(data_in[ai-1])/Integer.parseInt(data_in[ai+1]);
                                                data_in[ai-1]=String.valueOf(mul);
                                                data_in[ai]="";data_in[ai+1]="";
                                            }          
                                            
                                        }
                                        
                                        for(int j=0,k=0;j<count_arr;j++)
                                        {
                                            if(!data_in[j].equals(""))
                                            {
                                                div_data[k]=data_in[j];
                                                k++;
                                            }
                            
                                        }                                   
                                        
                            }
                                int count4=0;
                                for(String a:div_data)
                                {      
                                   // System.out.println(a);       
                                    if(a.equals("="))
                                    {
                                        ln_count=count4;
                                        break;
                                    }
                                    count4++;             
                                                
                                }

                                for(int i=0;i<ln_count+1;i++)
                                    {
                                    
                                        if(div_data[i].equals("*"))
                                        {    
                                            if(div_data[i-1].equals("")) 
                                            {
                                                mul=Integer.parseInt(div_data[i-3])*Integer.parseInt(div_data[i+1]);
                                                div_data[i-3]=String.valueOf(mul);
                                                div_data[i]="";div_data[i+1]="";
                                            } 
                                            else
                                            {
                                            
                                                mul=Integer.parseInt(div_data[i-1])*Integer.parseInt(div_data[i+1]);
                                                div_data[i-1]=String.valueOf(mul);
                                                div_data[i]="";div_data[i+1]="";
                                            }          
                                            
                                        }
                                        
                                        for(int j=0,k=0;j<ln_count+1;j++)
                                        {
                                            if(!div_data[j].equals(""))
                                            {
                                                mul_data[k]=div_data[j];
                                                k++;
                                            }

                                        }            
                                    }
                                    int count=0;
                                    for(String a:mul_data)
                                    {      
                                    // System.out.println(a);       
                                        if(a.equals("="))
                                        {
                                            ln_count=count;
                                            break;
                                        }
                                        count++;             
                                                    
                                    }
    
                            for(int m=0;m<ln_count+1;m++)
                            {           
                                if(mul_data[m].equals("+"))
                                {
                                    
                                    if(mul_data[m-1].equals(""))
                                    {
                                        add=Integer.parseInt(mul_data[0])+Integer.parseInt(mul_data[m+1]);
                                        mul_data[0]=String.valueOf(add);
                                        mul_data[m]="";mul_data[m+1]="";
                                    }
                                    else if(!mul_data[m-1].equals("")&& !mul_data[m+1].equals(""))
                                    {
                                        
                                        if(mul_data[m-1].equals(""))
                                        {
                                            add=Integer.parseInt(mul_data[m-3])+Integer.parseInt(mul_data[m+1]);                           
                                            mul_data[m-3]=String.valueOf(add);
                                            mul_data[m]="";mul_data[m+1]="";
                                        }
                                        else
                                        {
                                            add=Integer.parseInt(mul_data[m-1])+Integer.parseInt(mul_data[m+1]);                           
                                            mul_data[m-1]=String.valueOf(add);
                                            mul_data[m]="";mul_data[m+1]="";
                                        }
                                        
                                    }
                                
                                }
        
                            for(int j=0,k=0;j<ln_count+1;j++)
                            {
                                if(!mul_data[j].equals(""))
                                {
                                    add_data[k]=mul_data[j];
                                    k++;
                                }

                            }
                   }
                int count2=0;
                for(String b:add_data)
                {
                    //System.out.println(b);
                    if(b.equals("="))
                    {
                        ln_count=count2;
                        break;
                    }
                    count2++;
                    
                }
                   for(int i=0;i<ln_count+1;i++)
                        {
                            if(add_data[i].equals("-"))
                            {
                                    if(add_data[i-1].equals(""))
                                    {
                                        sub=Integer.parseInt(add_data[i-3])-Integer.parseInt(add_data[i+1]);                           
                                        add_data[i-3]=String.valueOf(sub);
                                        add_data[i]="";add_data[i+1]="";
                                    }
                                    else
                                    {
                                        sub=Integer.parseInt(add_data[i-1])-Integer.parseInt(add_data[i+1]);                           
                                        add_data[i-1]=String.valueOf(sub);
                                        add_data[i]="";add_data[i+1]="";
                                    }
                                        
                            }
                            for(int j=0,k=0;j<ln_count+1;j++)
                                {
                                    if(!add_data[j].equals(""))
                                    {
                                        sub_data[k]=add_data[j];
                                        k++;
                                    }

                                }
                        }
                        int count3=0;
                        for(String c:sub_data)
                        {
                            //System.out.println(c);           
                            
                        }
                        if(sub_data[1].equals("="))
                        {
                           //System.out.println("Final value:"+sub_data[0]);
                           String result_data=sub_data[0];                          
                           txt.setText(outstring+result_data);
                        }
                  }  
                  
                }
                  
                }          
                
              

          };
          btn.addActionListener(click);   
          
          ActionListener click_rst=new ActionListener(){
            public void actionPerformed(ActionEvent e)
            { 
                
            }
        };
        rest.addActionListener(click_rst);       
       }   
        frame.add(rest);      
        frame.add(txt); 
        frame.add(panel);       
        frame.setLayout(null);
        frame.setVisible(true);       

   
      
      
      

    }
}