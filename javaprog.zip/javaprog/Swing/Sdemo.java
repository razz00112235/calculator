import java.awt.*;
import javax.swing.JFrame;
import javax.swing.plaf.LabelUI;

import java.awt.Color;
public class Sdemo{

    public static void main(String[] args) {
        JFrame frame=new JFrame("CCTNS");
        frame.setSize(500, 500);
        frame.setLayout(null);
        frame.setVisible(true);

        Button bt1=new Button("Click A");
        Button bt2=new Button("Click B");
        Button bt3=new Button("Click C");
        Button bt4=new Button("Click D");

        bt1.setBounds(100, 100,100,50);
        bt1.setBackground(Color.green);
        Font font = new Font("Arial", Font.BOLD, 18);
        bt1.setFont(font);
                
        bt2.setBounds(100, 200,100,50);
        bt2.setBackground(Color.blue);
        bt1.setForeground(Color.white);

        bt3.setBounds(100, 300,100,50);
        bt3.setBackground(Color.red);
        
        bt4.setBounds(100, 400,100,50);
        bt4.setBackground(Color.pink);
        
        
        frame.add(bt1);
        frame.add(bt2);
        frame.add(bt3);
        frame.add(bt4);

        Label lb=new Label("hello");
        lb.setBounds(10, 10, 100, 20);
        lb.setBackground(Color.orange);
        frame.add(lb);

        
    }
}