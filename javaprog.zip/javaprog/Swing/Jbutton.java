
import java.awt.*;
import javax.swing.*; 
import javax.swing.JFrame;
import javax.swing.plaf.LabelUI;

import java.awt.Color;
public class Jbutton{

    public static void main(String[] args) {
        JFrame frame=new JFrame("CCTNS");

        JButton bt1=new JButton("Click A");
        JButton bt2=new JButton("Click B");
        JButton bt3=new JButton("Click C");
        JButton bt4=new JButton("Click D");
        JButton bt5=new JButton("Click E");
        
        frame.setSize(300, 400);
        frame.setLayout(new BorderLayout(30,10));
        
        frame.add(bt1,BorderLayout.EAST);
        frame.add(bt2,BorderLayout.WEST);
        frame.add(bt3,BorderLayout.CENTER);
        frame.add(bt4,BorderLayout.NORTH);
        frame.add(bt5,BorderLayout.SOUTH);
        
        frame.setVisible(true);

      

    }
}