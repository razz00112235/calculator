import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Simplecal{

     static int sum=0,get_num,count=0;
    public static void main(String[] args) {
        
        JFrame frame=new JFrame("Panel Calculator");
        frame.setSize(500,600);
        JTextArea txt=new JTextArea();
        txt.setBounds(10, 10, 460, 100);
        txt.setBackground(Color.pink);

        JButton plus=new JButton("+");
        plus.setBounds(10, 200, 100, 50);

        JTextArea show=new JTextArea();
        show.setBounds(10, 300, 460, 100);

        frame.add(txt); frame.add(plus);frame.add(show);          
        frame.setLayout(null);
        frame.setVisible(true);  
        
        ActionListener click=new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {  
                get_num=Integer.parseInt(txt.getText());
                show.setText(String.valueOf(get_num));
                txt.setText("");
                count++;
                String opr=plus.getText();
                if(count>0)
                {
                    show.getText();
                }
            }
        };

        plus.addActionListener(click); 
    }
}