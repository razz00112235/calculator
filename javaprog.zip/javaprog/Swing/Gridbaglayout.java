
import java.awt.*;
import javax.swing.*; 
import javax.swing.JFrame;
import javax.swing.plaf.LabelUI;

import java.awt.Color;
public class Gridbaglayout{

    public static void main(String[] args) {
        JFrame frame=new JFrame("GRID BAG LAYOUT");

        JButton bt1=new JButton("Click A");
        JButton bt2=new JButton("Click B");
        JButton bt3=new JButton("Click C");
        JButton bt4=new JButton("Click D");
        JButton bt5=new JButton("Click E");
        JButton bt6=new JButton("Click F");
        JButton bt7=new JButton("Click G");
        frame.setSize(300, 400);
        JPanel panel=new JPanel();        
        GridBagLayout layout = new GridBagLayout(); 
        panel.setLayout(layout); 
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;        
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(bt1,gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(bt2,gbc);
        gbc.gridx = 2;
        gbc.gridy = 0;
        panel.add(bt3,gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(bt4,gbc);
        gbc.gridx = 2;
        gbc.gridy = 1;
        panel.add(bt5,gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(bt6,gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth=3;
        gbc.ipady=20;
        gbc.gridx=0;
        gbc.gridy=3;
        panel.add(bt7,gbc);        
        frame.add(panel);
        frame.setVisible(true);

      

    }
}