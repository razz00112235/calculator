import java.net.*;
import java.io.*;
import java.util.*;

class Clientdata{

    public static void main(String[] args) {
        try {
                Register rg=new Register();
                Socket s=new Socket("localhost",8005);
                System.out.println("Client connected");
                String msg,name,mail;
                int id;
                Scanner sc=new Scanner(System.in);
                while(true)
                {
                    DataInputStream dis=new DataInputStream(s.getInputStream());  
                    DataOutputStream dout=new DataOutputStream(s.getOutputStream());

                    msg=dis.readUTF();
                    System.out.println(msg);
                   
                    name=sc.nextLine();        
                    dout.writeUTF(name); 

                    msg=dis.readUTF();
                    System.out.println(msg);
                   
                    mail=sc.nextLine();        
                    dout.writeUTF(mail); 

                    msg=dis.readUTF();
                    System.out.println(msg);
                   
                    id=sc.nextInt();        
                    dout.writeInt(id); 

                   
                }
        } catch (Exception e) {
            // TODO: handle exception
        }
        
    }
}