import java.util.*;

import java.lang.Math;   
import java.net.*;
import java.io.*;

class Register{

    static void register(String name,int id,String mail)
    {
        try {
            // int pass[]=new int[8];
            // int user_pass=0;
            //     System.out.println(name+"+"+mail+"+"+id);
            //     Random rn=new Random();
                
            //     for(int i=0;i<8;i++)
            //     {
            //         pass[i]= rn.nextInt(9);
            //     }
            //     for(int a:pass)
            //     {
            //         user_pass=(user_pass*10)+a;
            //     }
           
              
                
        } catch (Exception e) {
            System.out.println(e);
        }
        
    }
  
    public static void main(String[] args) {
        
        try {
            ServerSocket ss=new ServerSocket(8005); 
            String name,msg,mail;
            int id;
            while(true)
            {
                    Socket s=ss.accept();                   
                    System.out.println("Server Running");

                    DataInputStream dis=new DataInputStream(s.getInputStream());  
                    DataOutputStream dout=new DataOutputStream(s.getOutputStream());

                    msg="Enter your Name";     
                    dout.writeUTF(msg); 
                    
                    name=dis.readUTF();
                    System.out.println(name);

                    msg="Enter your mail id";     
                    dout.writeUTF(msg); 

                    mail=dis.readUTF();
                    System.out.println(mail);

                    msg="Enter your Department ID";     
                    dout.writeUTF(msg); 

                    id=dis.readInt();
                    System.out.println(id);
                    
                   register(name,id,mail);
                    
            }
           
        } catch (Exception e) {
            // TODO: handle exception
        }      
       
    
        
    }
}