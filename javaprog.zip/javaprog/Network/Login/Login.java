import java.util.*;
import java.net.*;
import java.io.*;

class Login{

  static void login()
     {
        
    }
    public static void main(String[] args) {
        login();
    }
}