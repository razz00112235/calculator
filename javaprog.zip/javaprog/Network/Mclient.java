import java.net.*;
import java.io.*;
import java.util.*;


public class Mclient extends Thread{
    static String msg="",str="";
    public void callClient()
    {
        try {
            Scanner sc=new Scanner(System.in);
            Socket s=new Socket("localhost", 8001);
            System.out.println("Connected to Server Client 1");                            
             
            DataOutputStream dout=new DataOutputStream(s.getOutputStream());
            DataInputStream dis=new DataInputStream(s.getInputStream()); 
          
            Thread recievemsg = new Thread(new Runnable(){
                public void run(){                           
                    try {  
                        str=dis.readUTF();
                        System.out.println(str);
                    } catch (Exception es) {
                        System.out.println(es);
                    }      
                    
                }
            });
            recievemsg.start();  
            Thread sendmsg = new Thread(new Runnable(){
                public void run(){   
                    msg=sc.nextLine(); 
                    try {     
                        dout.writeUTF(msg);  
                    } catch (Exception es) {
                        System.out.println(es);
                    }      
                    
                }
            });
            sendmsg.start();
           
                // str=dis.readUTF();
                // System.out.println(str);

                // msg=sc.nextLine();
                // dout.writeUTF(msg);

            
        } catch (Exception e) {
           System.out.println(e);
        }
    }

    public static void main(String[] args) {
        Mclient mc=new Mclient();
        mc.callClient();
        
       
    }
}