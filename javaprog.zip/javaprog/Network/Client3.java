import java.io.*;  
import java.net.*;  
import java.util.*;
public class Client3 {  
public static void main(String[] args) {  
try{      
    Scanner sc=new Scanner(System.in);
    String str="",msg="";

    Socket s=new Socket(8001);
while(true)
{
         
        
        System.out.println("client running....");
        DataInputStream dis=new DataInputStream(s.getInputStream());  
        DataOutputStream dout=new DataOutputStream(s.getOutputStream());
        
       
        while(true)
        {
                         
                
                str=dis.readUTF();
                System.out.println(str);                
               
                msg=sc.nextLine();        
                dout.writeUTF(msg);  
                if(msg.equals("off"))
                {
                    break;
                }
        }
    
}

}catch(Exception e){System.out.println(e);}  
}  
}  