import java.net.*;
import java.io.*;
import java.util.*;
public class Client{

    public static void main(String[] args) {
        try {
            Socket s=new Socket("localhost", 8001);
            //Socket s=new Socket("10.68.98.85", 8070);
            System.out.println("Connected to Server Client 1");            
            String st="",data=""; 
            int num;                             
            Scanner rd=new Scanner(s.getInputStream());                    
                                
            while(true)
            {
               
                st=rd.nextLine();
                if(st.equals("stop"))   
                {
                    System.out.println("server wants stop");
                    break;
                }
               
                System.out.println(st);  
                Scanner sc=new Scanner(System.in);
                
                if(st.equals("num"))
                {                    
                    num=sc.nextInt();
                    PrintStream ps=new PrintStream(s.getOutputStream()); 
                    ps.println(num);    
                }
                else
                {
                    data=sc.nextLine();
                PrintStream ps=new PrintStream(s.getOutputStream()); 
                ps.println(data);   
                }
                
            }
            System.out.println("Server check");
            s.close();
          
        } catch (Exception e) {
            // TODO: handle exception
        }
       
    }
}