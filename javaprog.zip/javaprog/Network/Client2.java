import java.net.*;
import java.io.*;
public class Client2{

    public static void main(String[] args) {
        try {
            //Socket s=new Socket("localhost", 8082);
            Socket s=new Socket("10.68.98.201", 8080);
            
            System.out.println("Connected to Client 2 Server");
            while(true)
            {
                
            }
        } catch (Exception e) {
            // TODO: handle exception
        }
       
    }
}