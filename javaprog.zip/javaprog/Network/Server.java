import java.net.*;
import java.io.*;
import java.util.*;
public class Server{

    public static void main(String[] args) {
        try {
            
            ServerSocket ss=new  ServerSocket(8082);
            while(true) 
            {
                Socket s=ss.accept();       // Establish a connection
                System.out.println("Connection Establish...");

                Scanner sc=new Scanner(System.in);
                String val="",getdata="";
                int numdata;
                
                while(true)
                {
                    PrintStream ps=new PrintStream(s.getOutputStream());    
                    val=sc.nextLine();           
                    ps.println(val); 
                    Scanner sc1=new Scanner(s.getInputStream());
                    getdata=sc1.nextLine();
                    boolean demo = getdata.chars().allMatch( Character::isDigit );
                   
                    if(demo==true)
                    {
                        
                        numdata = Integer.parseInt(getdata);
                            if(numdata%2==0)
                            {
                                System.out.println("Even numbers");
                            }
                            else
                            {
                                System.out.println("Odd numbers");
                            }
                        
                   
                    }
                    
                        System.out.println(getdata); 
                   
                    
                     
                    if(getdata.equals("stop"))
                    {
                        System.out.println("client want stop");
                        break;
                    }
                    
                }      
                                        
                
            }   
           

        } catch (Exception e) {
           
        }
    }
}