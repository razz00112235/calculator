import java.net.*;
import java.io.*;
import java.util.*;

class Client{

    public static void main(String[] args) {
        try {
                Socket s=new Socket("localhost",8009);
                System.out.println("Client connected");
                while(true)
                {
                    
                }
        } catch (Exception e) {
            // TODO: handle exception
        }
        
    }
}