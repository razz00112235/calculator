import java.net.*;
import java.io.*;
import java.util.*;
class Server1{

    public static void main(String[] args) {
        try {
            ServerSocket ss=new ServerSocket(8009);
                System.out.println("server Running");
                while(true)
                {
                    Socket s=ss.accept();
                    System.out.println("server Connected");
                }
        } catch (Exception e) {
            // TODO: handle exception
        }
        
    }
}