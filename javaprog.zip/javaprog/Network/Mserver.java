import java.io.*;  
import java.net.*;  
import java.util.*;

public class Mserver extends Thread {  
    static String msg="",str="";
  public void callServer()
  {
    Scanner sc=new Scanner(System.in);
    
    try{   
            ServerSocket ss=new ServerSocket(8001);
                
                while(true)
                {
                        Socket s=ss.accept();
                        InetSocketAddress socketAddress=(InetSocketAddress)s.getRemoteSocketAddress();
                        System.out.println(socketAddress);
                        System.out.println("Server Running");
                        System.out.println("client connected"); 
                        DataOutputStream dout=new DataOutputStream(s.getOutputStream());
                        DataInputStream dis=new DataInputStream(s.getInputStream());  
                        Thread send_sever = new Thread(new Runnable(){
                            public void run(){                                    
                                 
                                try {
                                     msg=sc.nextLine();
                                    dout.writeUTF(msg);
                                } catch (Exception es) {
                                    System.out.println(es);
                                }      
                                
                            }
                        });
                        send_sever.start(); 
                        Thread receive_sever = new Thread(new Runnable(){
                            public void run(){ 
                                try {
                                    str=dis.readUTF();
                                    System.out.println(str);
                                } catch (Exception er) {
                                    System.out.println(er);
                                }                                  
                               
                                
                            }
                        });
                        receive_sever.start();  
                       /* while(true)
                        {
                            // msg=sc.nextLine();
                            // dout.writeUTF(msg);

                            // str=dis.readUTF();
                            // System.out.println(str);
     
                        }*/
            
                }
        }catch(Exception e){System.out.println(e);}  
  }

public static void main(String[] args){  
    Mserver ms=new Mserver();
    ms.callServer();
   
  }  
}  