import java.util.*;

import javax.annotation.processing.SupportedOptions;

import java.net.*;
import java.io.*;

class Urlcon{

    public static void main(String[] args) {
        
        try {
           
            URL url=new URL("https://www.google.com");
            HttpURLConnection url_data=(HttpURLConnection)url.openConnection();
            url_data.setRequestMethod("GET");

            InputStreamReader in=new InputStreamReader(url_data.getInputStream());
            BufferedReader in1=new BufferedReader(in);
            String st="";
            File objfile=new File("googledata.txt");
            Scanner sc=new Scanner(objfile);
            FileWriter file = new FileWriter("googledata.txt",true);
          
            while(st!=null)
            {
                st=in1.readLine();
               // System.out.println(st);
                file.write(st+"\n");
                
            }
           
             in1.close(); 
             file.close();                 
             System.out.println("File Data Stored 3");
           
            

        } catch (Exception e) {
            // TODO: handle exception
        }
    }
}