import java.net.*;
import java.util.*;

class Url{

    public static void main(String[] args) {
        
        try{
              
   
            System.out.println("-----------------------");
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter a valid Url");
            String url_enter=sc.nextLine();
            URL url=new URL(url_enter);  
            InetAddress ip=InetAddress.getByName(url.getHost());
            System.out.println("IP Address: "+ip.getHostAddress()); 
            System.out.println(url.getProtocol());        
            System.out.println(url.getPort());
            System.out.println(url.getFile());
            System.out.println(url.getHost());

           
            
            System.out.println(url.getUserInfo());
            System.out.println(url.getContent());
            System.out.println(url.getClass());

            URLConnection con=url.openConnection();
            System.out.println(con);
            
        }catch(Exception e)
        {
            System.out.println(e);
        }
        
    }
}