import java.io.*;  
import java.net.*;  
import java.util.*;

public class Server2 {  
public static void main(String[] args){  
try{   
    Scanner sc=new Scanner(System.in);
    String msg="",str="";
  InetAddress ip_address=InetAddress.getLocalHost();
    System.out.println(ip_address);
    System.out.println(ip_address.getHostName());
    ServerSocket ss=new ServerSocket(6666); 

while(true)
{
        Socket s=ss.accept();
        InetSocketAddress socketAddress=(InetSocketAddress)s.getRemoteSocketAddress();
        System.out.println(socketAddress);
        String ClientIpAddress= socketAddress.getAddress().getHostAddress();
        //System.out.println(socketAddress.getAddress());
        System.out.println(ClientIpAddress);
        System.out.println("server running...");
        System.out.println("Client wants conected");
        
    while(true)
    {       
        DataOutputStream dout=new DataOutputStream(s.getOutputStream());
        msg=sc.nextLine();        
        dout.writeUTF(msg); 

        DataInputStream dis=new DataInputStream(s.getInputStream());  
        str=dis.readUTF();
       
        if(str.equals("off"))
                {
                    System.out.println("client wants disconnect");
                    break;
                }
                else{
                    System.out.println(str);
                }
                
    }                            
    msg=sc.nextLine(); 
   
}


}catch(Exception e){System.out.println(e);}  
}  
}  