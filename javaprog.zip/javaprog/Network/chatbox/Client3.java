import java.io.*;  
import java.net.*;  
import java.util.*;
public class Client3 {  
public static void main(String[] args) {  
try{      

Scanner sc=new Scanner(System.in);
String msg="",str="",con="",start="";
  


while(true)
{
    con=sc.nextLine();   
    if(con.equals("on"))
    {       
        Socket s=new Socket("10.68.98.214",8001);
        System.out.println("client running....");
        DataInputStream dis=new DataInputStream(s.getInputStream());  
        DataOutputStream dout=new DataOutputStream(s.getOutputStream());
        
       
        while(true)
        {
                         
                
                str=dis.readUTF();
                System.out.println(str);                
               
                msg=sc.nextLine();        
                dout.writeUTF(msg);  
                if(msg.equals("off"))
                {
                    break;
                }
        }
       
    }
                                    

    
}


}catch(Exception e){System.out.println(e);}  
}  
}  