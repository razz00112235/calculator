import java.io.*;  
import java.net.*;  
import java.util.*;

public class Server2 {  
public static void main(String[] args){  
try{   
    Scanner sc=new Scanner(System.in);
    String str="",msg="";
    ServerSocket ss=new ServerSocket(8001); 
    
    int i=1;
while(true)
{
        Socket s=ss.accept();
        InetSocketAddress socketAddress=(InetSocketAddress)s.getRemoteSocketAddress();
        System.out.println(socketAddress);
        System.out.println("Server Running");
        System.out.println(i+"client connected");
        i++;

        while(true)
        {
            DataOutputStream dout=new DataOutputStream(s.getOutputStream());
            msg=sc.nextLine();        
            dout.writeUTF(msg); 

            DataInputStream dis=new DataInputStream(s.getInputStream());  
            str=dis.readUTF();
            System.out.println(str);

            if(str.equals("off"))
            {
                break;
            }
        }
        
        

        
        
}


}catch(Exception e){System.out.println(e);}  
}  
}  