import java.net.SocketPermission;

import javax.annotation.processing.SupportedOptions;

interface Prog{
    void msg();
}
 class Demo implements Prog{
    int a=10;
    public void msg(){
        System.out.println("hello msg");
    }
 }
public class Hello
{

    public static void main(String [] args)
    {
        System.out.println("Hello Java");
         Demo obj=new Demo();
         obj.msg();
         int b=5;
         b=b+obj.a;
         System.out.println(b);
    }
}