import java.util.*;

public class Classdemo{

    public static void main(String[] args) {
        Random rc=new Random();
        Scanner sc=new Scanner(System.in);
        String data[]={"Rock","Scissor","Paper"};
        System.out.println("Enter a String Rock/Scissor/Paper");
        int index,user_count=0,comp_count=0;

        for(int i=0;i<3;i++)
        {
            String name=sc.next();
            index=rc.nextInt(data.length);
            if(name.equals(data[index]))
            {
                user_count++;
                comp_count++;
                System.out.println("Computer data "+data[index]+" Tie");
            }
            else if(name.contains("Rock") && data[index].contains("Scissor"))
            {
                user_count++;
                System.out.println("Computer data "+data[index]+" User Win");
            }
            else if(name.contains("Paper") && data[index].contains("Rock"))
            {
                user_count++;
                System.out.println("Computer data "+data[index]+" User Win");
            }
            else if(name.contains("Scissor") && data[index].contains("Paper"))
            {
                user_count++;
                System.out.println("Computer data "+data[index]+" User Win");
            }
            else if(name.contains("Scissor") && data[index].contains("Rock"))
            {
                comp_count++;
                System.out.println("Computer data "+data[index]+" Computer Win");
            }
            else if(name.contains("Rock") && data[index].contains("Paper"))
            {
                comp_count++;
                System.out.println("Computer data "+data[index]+" Computer Win");
            }
            else if(name.contains("Paper") && data[index].contains("Scissor"))
            {
                comp_count++;
                System.out.println("Computer data "+data[index]+" Computer Win");
            }            
           
        }
        if(user_count>comp_count)
        {
            System.out.println("Finally User win");
        }
        else if(comp_count>user_count)
        {
            System.out.println("Finally Computer win");
        }
        else
        {
            System.out.println("Finally Tie Data");
        }


    }
}