import java.util.*;
import java.net.*;
import java.io.*;
import java.io.File;

import java.util.Scanner; 
class Login{
      static void login(String pass)
      {

        try {
            String password=pass; 
            int count=0;
            System.out.println(password);
            File check_data = new File("Userdata.txt");
            Scanner rd = new Scanner(check_data);
            while (rd.hasNextLine()) {
            String data = rd.nextLine();           
            if(data.contains(password))
             {
                count++;
             }
            
            }

            if(count==1)
            {
               System.out.println("Login Success....");
            }
            else
            {
               System.out.println("Incorrect User Details");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
           
      }
 
    public static void main(String[] args) {
        try {

            ServerSocket ss=new ServerSocket(8005);             
            String password;
            while(true)
            {
                    Socket s=ss.accept();                   
                    System.out.println("Server Running");

                    DataInputStream dis=new DataInputStream(s.getInputStream());   
                    password=dis.readUTF();
                    System.out.println(password);
                    login(password);


            }
            
    } catch (Exception e) {
       System.out.println(e);
    }
    }
}