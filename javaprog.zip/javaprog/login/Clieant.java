import java.net.*;
import java.io.*;
import java.util.*;

public class Clieant
{
    public static void main(String[] args) 
    {
        try
        {          
            while(true)
            {
                Scanner sc = new Scanner(System.in);
                System.out.println("Enter your name");
                String name = sc.nextLine();
                System.out.println("Enter your id");
                String dpid = sc.nextLine();
                System.out.println("Enter youe email");
                String email = sc.nextLine();
                

                                

                FileWriter fw = new FileWriter("Userdata.txt",true);
                fw.append(name+" ");
                fw.append(dpid+" ");
                fw.append(email+"\n");
                
                fw.close();
                System.out.println("Connected to server");
            }
        }

        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}

