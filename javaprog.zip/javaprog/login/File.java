import java.util.*;

class File{

 static int demo(int a,String b,String c)
  {
    int x=a;
    try {
     
       System.out.println("hello");
      
    } catch (Exception e) {
      // TODO: handle exception
    }
    return x;  
  }
  public static void main(String[] args) {
    
    demo(1,"ram","shyam");
    int d=demo(1,"ad","cd");
  }
}