import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class Socketlbl{

   static void frame1()
     {
        
        JFrame frame1=new JFrame("Client App");
        frame1.setSize(400,400);
        frame1.setLayout(null);
        
        JButton on,off;        
        on=new JButton("ON");  
        on.setBounds(250, 50, 100, 50); 
        off=new JButton("OFF");
        off.setBounds(250, 250, 100, 50); 

        JLabel onlb=new JLabel("Switch ON");     
        JLabel offlb=new JLabel("Switch OFF");
        
        frame1.add(on);
        frame1.add(off); 
        frame1.add(onlb); 
        frame1.add(offlb);  
        frame1.setVisible(true);

        JFrame frame2=new JFrame("Socket Program Frame2");
       // frame2.setSize(200,200);
       frame2.setBounds(450,00,300,300);
        frame2.setLayout(null);
        
        
        JLabel output=new JLabel("Switch Off");
        output.setBounds(100, 100,150, 50);
        frame2.add(output);                   
        frame2.setVisible(true);
        
        ActionListener on_click=new ActionListener(){
            public void actionPerformed(ActionEvent e)
            { 
                frame2.setVisible(true);
                output.setText("Switch ON");            
            }

        };
        on.addActionListener(on_click); 
        ActionListener off_click=new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {    frame2.setVisible(true);      
                 output.setText("Switch OFF");         
               
            }

        };
        off.addActionListener(off_click); 
        

     }

//   static void frame2(String data)
//      {
//         JFrame frame2=new JFrame("Socket Program Frame2");
//         frame2.setSize(200,200);
//         frame2.setLayout(null);
        
//         JLabel output=new JLabel();
//         output.setBounds(100, 100,150, 50);
//         frame2.add(output);                   
//         if(data.contains("ON"))
//         {            
//             output.setText("ON Switch");                     
//         }
//         else
//         {       
//             output.setText("OFF Switch");
//         }  
//         frame2.setVisible(true);
                    
       
//      }
    public static void main(String[] args) {
        frame1();
        
       

    }
}