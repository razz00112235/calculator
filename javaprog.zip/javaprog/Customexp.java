import java.util.*;

class Airthmaticexp extends Exception{
    Airthmaticexp(String st)
    {
        super(st);
        System.out.println("your age not eligible");
    }
}
class Customexp{
 
     
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter age");
        int age=sc.nextInt();
        try{
            if(age<18)
            {
                throw new Airthmaticexp("Not Eligible");
            }
            else{
                System.out.println("Eligible for voting");
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}