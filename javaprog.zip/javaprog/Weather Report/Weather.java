import java.util.*;
import java.net.*;
import java.io.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class Weather{

    static void weather(String city_name,String state_name)
    {
      try {
        JSONParser par3=new JSONParser();
        Object objdata = par3.parse(new FileReader("statedata.json"));
        JSONObject obj2=(JSONObject)objdata;
        String state = state_name.substring(0, 1).toUpperCase() + state_name.substring(1);

        //System.out.println(state);
        Object State_data=obj2.get(state);
      
         URL url=new URL("http://api.openweathermap.org/geo/1.0/direct?q="+city_name+","+State_data+",IN&limit=10&appid=b535fff314794c34cb57ab212fb13379");
         HttpURLConnection url_data=(HttpURLConnection)url.openConnection();
         url_data.setRequestMethod("GET");

         InputStreamReader in=new InputStreamReader(url_data.getInputStream());
         BufferedReader in1=new BufferedReader(in);
         String st="";
          st=in1.readLine();            
                 JSONParser par=new JSONParser();
                 JSONArray arr=(JSONArray)par.parse(st);
                     JSONObject obj=(JSONObject)arr.get(0);                      
                     Object city,lat,lng,lname;
                 
                     city=obj.get("name");
                     lat=obj.get("lat");
                     lng=obj.get("lon");
                    // System.out.println("\n");                 
                    //  System.out.println("\n"+city+" latutide is: "+lat+", Longitude is: "+lng);     
         URL url2=new URL("https://api.openweathermap.org/data/2.5/weather?lat="+lat+"&lon="+lng+"&appid=b535fff314794c34cb57ab212fb13379");
         HttpURLConnection url_data2=(HttpURLConnection)url2.openConnection();
         url_data2.setRequestMethod("GET");

         InputStreamReader in2=new InputStreamReader(url_data2.getInputStream());
         BufferedReader in12=new BufferedReader(in2);
         String st2="";         
         st2=in12.readLine();    
        //  System.out.println(st2);           
         JSONParser par2=new JSONParser();
         JSONObject arr2=(JSONObject)par2.parse(st2);             
         JSONObject obj3=(JSONObject)arr2.get("main");
         Object city_temp=obj3.get("temp");
         Double city_tmp=(Double)obj3.get("temp");
         city_tmp=city_tmp-273.15;         
         
         System.out.println("Today "+city+" Temprature is "+String.format("%.2f", city_tmp)+"°C");  

         JSONArray wth = (JSONArray)arr2.get("weather");
         JSONObject ob4 = (JSONObject)wth.get(0);
         Object weather=ob4.get("main");      
         
         System.out.println("Today Weather is: "+weather);
         Object Visible=arr2.get("visibility");
         System.out.println("Visibility in "+city+" is "+Visible+" Meters");
         Object wind=arr2.get("wind");
        
         JSONObject winddata=(JSONObject)wind;
         System.out.println("Air Speed is "+winddata.get("speed")+" km/h");

        //  JSONObject wind=(JSONObject)arr2.get("wind");
        //  Object wind_speed=obj3.get("speed");
        //  System.out.println("Today Windspeed is: "+wind_speed);

         

                
                 
      } catch (Exception e) {
         System.out.println(e);
      }    
    }
    public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter your State Name");
      String state_name=sc.nextLine();
      System.out.println("Enter your City Name");
      String city_name=sc.nextLine();
        weather(city_name,state_name);
         
        
     
     
    }
}