import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Cal{

    public static void main(String[] args) {
        
        JFrame frame=new JFrame("Panel Calculator");
        frame.setSize(500,500);
        JTextArea txt=new JTextArea();
        txt.setBounds(10, 10, 460, 100);
        txt.setBackground(Color.pink);
        
       JButton b1=new JButton("1");
       b1.setBounds(100,100,100,50);
       JButton b2=new JButton("2");
       b2.setBounds(100,100,100,50);
       JButton b3=new JButton("3");
       b3.setBounds(100,100,100,50);
       JButton add=new JButton("+");
       add.setBounds(100,100,100,50);
       JButton equal=new JButton("=");
       equal.setBounds(100,100,100,50);

       JPanel pn=new JPanel();
       pn.setBounds(0,120,500,320);    
       pn.setBackground(Color.gray);
       GridLayout gl=new GridLayout(4,4);
       pn.setLayout(gl);
       pn.add(b1);pn.add(b2);pn.add(b3);pn.add(add);pn.add(equal);

       frame.add(txt); 
       frame.add(pn);
       frame.setLayout(null);
       frame.setVisible(true);

       ActionListener click=new ActionListener(){        
        public void actionPerformed(ActionEvent e)           
        {
            txt.setText(b1.getText());
        }
    };
    b1.addActionListener(click);


    }

}