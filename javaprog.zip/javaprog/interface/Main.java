import java.util.*;
/*class Tcg 
{
    private String code;
    private int id;
    private String name;

    public String  setCode() 
    {
       return code;              
    }
    public void getCode(String code)
    {
        this.code=code;
        
    }
    public int  setId() 
    {
       return id;              
    }
    public void getId(int id)
    {
        this.id=id;
        
    }
    public String  setName() 
    {
       return name;              
    }
    public void getName(String name)
    {
        this.name=name;
        
    }
    
    void show()  
    {
        System.out.println("Candidate name: "+name);
        System.out.println("Candidate id: "+id);
        System.out.println("Candidate code: "+code);
    }
}

class Java extends Tcg
{

    void call() 
    {
     Scanner obj = new Scanner(System.in);
     System.out.println("Enter the your code");
     String cd=obj.next();
     getCode(cd);
     System.out.println("Enter your id");
     int i = obj.nextInt();
     getId(i);
     System.out.println("Enter your name");
     String na = obj.next();
     getName(na);

     show();
        
    }
    
    

}

public class Main 
{
    public static void main(String[] args) 
    {
        Java ob = new Java();                
        ob.call();

        
    }
    
}*/

import javax.sound.sampled.SourceDataLine;




/* 
class Tcg 
{
    private String code;
    private int id;
    private String name;  
    
    Tcg(String code,int id,String name)
    {
        this.code=code;
        this.id=id;
        this.name=name;
    }
    
    void show()  
    {
        System.out.println("Candidate name: "+name);
        System.out.println("Candidate id: "+id);
        System.out.println("Candidate code: "+code);
    }
}

class Java 
{ 

}

public class Main 
{
    public static void main(String[] args) 
    {
        Scanner ob = new Scanner(System.in);
        String code=ob.next();
        int id= ob.nextInt();
        String name=ob.next();      

        Tcg obj = new Tcg(code,id,name); 
        obj.show();

        
    }
    
}*/



class Tcg 
{
    private String code;
    private int id;
    private String name; 

    Tcg()
    {
        super(System.out.println("Super constracter: "));
    }
    Tcg(String code,int id,String name)
    {
        this.code=code;
        this.id=id;
        this.name=name;
    }
    
    void show()  
    {
        System.out.println("Candidate name: "+name);
        System.out.println("Candidate id: "+id);
        System.out.println("Candidate code: "+code);
    }
}



public class Main 
{
    Main()
    {
        super();
    }
    
    public static void main(String[] args) 
    {
       
        Tcg obj = new Tcg("12547854",1001,"ramkishore");
       
        super();
        obj.show();

        
    }
    
}



