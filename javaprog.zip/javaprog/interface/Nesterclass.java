
    /*class Tcg
    {
        class Java
        {
            void devlopber()
            {
                System.out.println("You are java devloper");
            }
        }
        class Server
        {
            void server()
            {
                System.out.println(" You are sever admin");
            }
        }
    }


public class Nesterclass  
{
    public static void main(String[] args) 
    {
        Tcg obj = new Tcg();
        
        Tcg.Java ab = obj.new Java();
        ab.devlopber();
        Tcg.Server cd = obj.new Server();
        cd.server(); 
    }
}*/



class Tcg
    {
        private class Java
        {
            private void devlopber()
            {
                System.out.println("You are java devloper");
            }
        }
        class Server extends Java
        {
            void server()
            {
                devlopber();
            }
        }
    }


public class Nesterclass  
{
    public static void main(String[] args) 
    {
       
        Tcg obj = new Tcg();
        Tcg.Server ab = obj.new Server();
        ab.devlopber();
         
    }
}