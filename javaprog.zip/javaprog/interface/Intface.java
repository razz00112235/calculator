import javax.sound.midi.Soundbank;
interface Demo{
    int a=10;
    void sum();
   
}
interface Demo2{    
    void mul();
   
}
class Result implements Demo,Demo2{
    int c=15;
    int d=c+a;
    public void sum(){
        System.out.println("Interface demo");
        System.out.println("Sum of a + b"+d);
    }
    
    public void mul(){
        System.out.println("Interface demo2");
        System.out.println("Sum of a + b"+d);
    }
}
 class Show implements Demo{
    int d=a+50;
    public void sum()
    {
        System.out.println("Interface demo");
        System.out.println("Sum of a + b"+d);
    }
 }
public class Intface {
    
     public static void main(String args[])
      {
           Result obj=new Result();
           Show obj2=new Show();
           obj.sum();
           obj.mul();
           int b=obj.a;
           int e=obj.c;
           System.out.println(b+e);
           obj2.sum();
           String name="Meghrajyadav";
           char[] ch=name.toCharArray();
           for(int i=0;i<ch.length;i++)
           {
                 System.out.print(ch[i]);
           }
           System.out.println("\n");
           for(char i:ch)
           {
            System.out.println(i);
           }
           System.out.println(name.substring(5,7));
           System.out.println(name.subSequence(5,7));
           String split_str[]=new String[50];
           String str = "hello is java is a are is java";
           split_str = str.split("s", 7);
           for (String a : split_str)
           {
            System.out.println(a);
           }
           System.out.println(str.replace("is","are"));
           System.out.println(str.replaceFirst("s","0"));
           System.out.println(str.replaceAll("s","-"));
           System.out.println(str.matches("java"));
           System.out.println(str.matches("(.*)java(.*)"));
           System.out.println(str.matches("(.*)java"));

             String myStr1 = "b";
             String myStr2 = "a";
             System.out.println(myStr1.compareTo(myStr2));


             String myStr11 = "Hello";
String myStr12 = "Hello";
String myStr13 = "Another String";
System.out.println(myStr11.equals(myStr12)); // Returns true because they are equal
System.out.println(myStr11.equals(myStr13));

           

      }
}
