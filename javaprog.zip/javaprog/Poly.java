import java.sql.PseudoColumnUsage;
import java.util.*;

class Sum{
    private int a=20;
    private int x;
    int sum(int x)
    {
         int b=25,c=b+a;
         this.x=x;
         int d=c+x;
          return d;
    }
}
class Poly{

public static void main(String[] args) {
     Sum obj=new Sum();
     System.out.println(obj.sum(25));
}
}